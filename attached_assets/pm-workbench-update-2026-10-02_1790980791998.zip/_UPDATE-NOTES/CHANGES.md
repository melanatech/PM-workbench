# PM Workbench update, 2 October 2026

Plans A–D. 98 files added or changed, 24 deleted. Paths are relative to the repository root. Extract the zip over the repo, then delete the files listed in DELETE-THESE.txt. The `_UPDATE-NOTES` folder is not part of the repo; remove it after use.

Tests: `python3 -m unittest discover -s pm-workbench/tests -v`. 108 pass here, 3 skipped (the browser keyboard test, no Chromium). None of this has run in Claude Code yet.

After extracting, re-mark the launchers executable: `chmod +x "pm-workbench/Run PM Workflow.command" "pm-workbench/Capture Clipboard.command"`.

## Plan A: /todo
- New: `.claude/commands/todo.md`, `.claude/agents/todo-worker.md`, `scripts/todo_register.py`, `fixtures/lumenly/registers/todos.csv`, `tests/test_todo.py`
- Changed: `validate_register_write.py` (todos.csv is a current-state register), `check_output_provenance.py` and `scripts/check_run.py` (TODO ids recognised), `CLAUDE.md`, `START HERE.md`, `CONNECTIONS.md`, `AGENTS.md`, `SETUP.md`, `BACKLOG.md`, the daily-brief, meeting-prep, prd-package, meeting-closeout and process-inbox workflows, the fixture README, `tests/manual-prompt-evals.md`

## Plan B: eight commands
- New: six router commands (`capture`, `brief`, `sync`, `discover`, `build`, `report`), `.claude/workflows/` (26 workflow files, `_protocol.md`, `routes.json`), `.claude/agents/workflow-runner.md`, `tests/test_routing.py`
- Deleted: the 24 old command files (DELETE-THESE.txt). Their text lives on, unchanged, in `.claude/workflows/`.
- Changed: `log_run.py` (logs `cluster:workflow`), `workbench_health.py`, `settings.json` and `settings.core.json` (skillOverrides), `SKILLS.md`, the launchers. Every file that named an old command now uses the router form.
- `/meeting-closeout` is now `/capture meeting-closeout`; `/prd-package` is now `/build prd-package`. `/quick-close` and `/todo` are unchanged.

## Plan C: evaluation
- New: `scripts/workbench_metrics.py`, `scripts/score_fixture.py`, `fixtures/lumenly/gold.json`, `reference/workbench-metrics.md`, `.claude/workflows/monthly-review.md`, `tests/test_metrics.py`
- Changed: `check_output_provenance.py` (records output hashes), `todo_register.py` (`log-proposal`), `workbench_health.py` (metrics section), `routes.json` and `report.md` (monthly-review), `SCHEDULING.md`

## Plan D: agent updates, stages 1–3
- New: `scripts/run_scheduled.py`, `.claude/loop.md`, `tests/test_scheduling.py`
- Changed: `SCHEDULING.md` (rewritten for the command line: OS scheduler plus `/loop`), `todo.md` (`sweep`, `propose queue`), `_protocol.md` (pause switch), `daily-brief.md` (overnight work), `workbench_metrics.py` (Unattended group), `CLAUDE.md` rule 22, `Run PM Workflow.command`

## Whole-project consistency pass
- `README.md`: fixed the first-run command; added commands at a glance, scoring, scheduling and metrics pointers, the repository map and the unverified row
- `docs/index.html`: command names updated throughout, new palette, scheduling lesson and sim rewritten for the command line, 26-workflow count. The lesson structure is otherwise unchanged, by decision.
- Workflow count corrected to 26 in CLAUDE.md, AGENTS.md, the README and the course

## Still unverified (see BACKLOG.md)
`/todo` name collision; model override on subagent dispatch; the router, runner, router question loop; `claude -p` expanding slash commands and dispatching the runner; `/loop` invoking name-only commands; `/insights`.
